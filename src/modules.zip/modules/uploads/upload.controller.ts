import { Controller, UploadedFiles, UseInterceptors } from "@nestjs/common";
import {  FilesInterceptor } from "@nestjs/platform-express";
import { multerOptions } from "./config";

@Controller( 'upload' )
export class UploadController {

    @UseInterceptors(FilesInterceptor("file", null,multerOptions))
    async UploadedFile(@UploadedFiles() file) {
        console.log(file)
    }
}